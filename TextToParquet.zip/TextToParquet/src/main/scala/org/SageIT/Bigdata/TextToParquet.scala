package org.SageIT.Bigdata
import org.apache.spark.sql.SparkSession


object TextToParquet {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.appName("TextToParquet").getOrCreate()

    val inputPath = args(0)
    val outputPath = args(1)

    val textDataFrame = spark.read.text("C://Users/vemul/OneDrive/Desktop/Technology.txt")

    textDataFrame.write.mode(SaveMode.Overwrite).parquet("C://Users/vemul/OneDrive/Desktop/output.parquet")

    spark.stop()
  }
}